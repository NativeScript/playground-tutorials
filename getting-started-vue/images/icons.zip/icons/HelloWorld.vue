<template>
    <Page class="page" @loaded="onPageLoaded">
        <!-- Having an ActionBar lets you change the status bar color on iOS, even if the ActionBar isn’t being used. -->
        <!-- See https://docs.nativescript.org/ui/change-status-bar-style-ios for details -->
        <ActionBar title=" " flat="true" v-bind:class="{ completed: activeTabIndex == 1 }" />

        <TabView :selectedIndex="activeTabIndex" @selectedIndexChange="onTabChange"
            selectedTabTextColor="#42B883" androidTabsPosition="bottom">
            
            <TabViewItem title="To Do" :iconSource="todoIcon" textTransform="uppercase">
                <!-- Positions a header, an input field, a button, and the list of tasks in a vertical stack. -->
                <GridLayout rows="auto, auto, *">
                    <Label row="0" class="header" text="My Tasks" />

                    <GridLayout row="1" columns="3*, *" rows="auto" class="input-bar">
                        <!-- Configures the text input field. -->
                        <TextField col="0" row="0" ref="taskInput" v-model="textFieldValue"
                            hint="Enter text..." editable="true" @returnPress="onReturnPress" />
                        <Button col="1" row="0" class="circle" text="+" @tap="onButtonTap" />
                    </GridLayout>

                    <ListView row="2" class="list-group" for="todo in todos"
                        @itemLoading="onItemLoading">
                        <v-template>
                            <GridLayout columns="auto, *" class="list-entry">
                                <Label col="0" v-on:tap="onTodoCircleTap(todo)"
                                    class="circle" text=" " />
                                <Label col="1" v-on:tap="onTodoItemTap(todo)"
                                    :text="todo.name" textWrap="true" />
                            </GridLayout>
                        </v-template>
                    </ListView>

                </GridLayout>
            </TabViewItem>
            <TabViewItem title="Completed" :iconSource="completedIcon"
                textTransform="uppercase">
                <GridLayout rows="auto, *">
                    <Label row="0" class="header completed" text="Completed Tasks" />

                    <ListView row="1" class="list-group" for="done in dones"
                        @itemLoading="onItemLoading">
                        <v-template>
                            <GridLayout columns="auto, *" class="list-entry list-entry-completed">
                                <Label col="0" v-on:tap="onCompletedCircleTap(done)"
                                    class="circle" text="✓" />
                                <Label col="1" v-on:tap="onCompletedItemTap(done)"
                                    :text="done.name" textWrap="true" />
                            </GridLayout>
                        </v-template>
                    </ListView>
                </GridLayout>
            </TabViewItem>
        </TabView>
    </Page>
</template>

<script>
    const platform = require("tns-core-modules/platform");
    const frame = require("tns-core-modules/ui/frame");

    export default {
        methods: {
            onTodoItemTap: function(item) {
                const index = this.todos.indexOf(item);
                action("What do you want to do with this task?", "Cancel",
                    [
                        "Mark completed",
                        "Delete forever"
                    ]).then(result => {
                    console.log(result); // Logs the selected option for debugging.
                    switch (result) {
                        case "Mark completed":
                            this.dones.unshift(item); // Places the tapped active task at the top of the completed tasks.
                            this.todos.splice(index, 1); // Removes the tapped active task.
                            this.activeTabIndex = 1; // Switches the tab to the completed tab.
                            break;
                        case "Delete forever":
                            this.todos.splice(index, 1); // Removes the tapped active task.
                            break;
                        case "Cancel" || undefined: // Dismisses the dialog.
                            break;
                    }
                });
            },

            onTodoCircleTap: function(item) {
                const index = this.todos.indexOf(item);
                this.dones.unshift(item); // Places the tapped active task at the top of the completed tasks.
                this.todos.splice(index, 1); // Removes the tapped active task.
                this.activeTabIndex = 1; // Switches the tab to the completed tab.
            },

            onCompletedItemTap(item) {
                const index = this.todos.indexOf(item);
                action("What do you want to do with this task?", "Cancel", [
                    "Mark to do",
                    "Delete forever"
                ]).then(result => {
                    console.log(result); // Logs the selected option for debugging.
                    switch (result) {
                        case "Mark to do":
                            this.todos.unshift(item); // Places the tapped completed task at the top of the ToDo tasks.
                            this.dones.splice(index, 1); // Removes the tapped completed task.
                            this.activeTabIndex = 0; // Switches the tab to the active task tab.
                            break;
                        case "Delete forever":
                            this.dones.splice(index, 1); // Removes the tapped completed task.
                            break;
                        case "Cancel" || undefined:
                            break;
                    }
                });
            },

            onCompletedCircleTap(item) {
                const index = this.todos.indexOf(item);
                this.todos.unshift(item); // Places the tapped completed task at the top of the ToDo tasks.
                this.dones.splice(index, 1); // Removes the tapped completed task.
                this.activeTabIndex = 0;
            },

            onButtonTap() {
                // Trims the provided string and checks if it's empty.
                if (this.textFieldValue.trim() === "") {
                    this.$refs.taskInput.nativeView.focus(); // Returns focus to the text field.
                    return;
                }
                console.log("New task added: " + this.textFieldValue + "."); // Logs the string in the console for debugging.
                this.todos.unshift({
                    name: this.textFieldValue
                }); // Adds the item in the ToDo array. Newly added tasks are immediately shown on the screen.
                this.textFieldValue = ""; // Clears the text field so that users can start adding new tasks immediately.
            },

            onReturnPress() {
                // Trims the provided string and checks if it's not empty.
                if (this.textFieldValue.trim() !== "") {
                    this.onButtonTap(); // Acts as if the in-app button was pressed.
                }
            },

            onTabChange(tab) {
                this.activeTabIndex = tab.value;
            },

            onPageLoaded: function() {
                if (platform.isIOS) {
                    // Since the ActionBar is a dark color, this snippet of code switches the app to use
                    // white text in the status bar for iOS.
                    const navBar = frame.topmost().ios.controller.navigationBar;
                    navBar.barStyle = UIBarStyle.UIBarStyleBlack;

                    // Hide the IQKeyboard default toolbar as it might confuse users in this simple example.
                    IQKeyboardManager.sharedManager().enableAutoToolbar =
                        false;
                }
            },

            onItemLoading(args) {
                if (args.ios) {
                    // Prevent default iOS behavior of highlighting a tapped item in a UITableView
                    // See https://stackoverflow.com/questions/46299915/remove-listview-item-highlight-on-tap-nativescript-angular-ios
                    args.ios.selectionStyle = UITableViewCellSelectionStyle.None;
                }
            }
        },

        data() {
            return {
                // Pre-fill a few tasks just for testing purposes.
                todos: [{
                        name: "Feed dogs"
                    },
                    {
                        name: "Ride bike"
                    },
                    {
                        name: "Go grocery shopping"
                    }
                ],
                dones: [],
                textFieldValue: "",
                activeTabIndex: "0",
                todoIcon: platform.isIOS ? "~/./images/To-Do@3x.png" : "",
                completedIcon: platform.isIOS ? "~/./images/Completed@3x.png" :
                    ""
            };
        }
    };
</script>

<style scoped>
    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }

    ActionBar {
        background-color: #35495E;
    }

    .header {
        background-color: #35495E;
        color: white;
        font-size: 34;
        font-weight: 600;
        padding: 0 15 15 15;
        margin: 0;
    }

    .completed {
        background-color: #42B883;
    }

    .input-bar {
        border-width: 0 0 1 0;
        border-color: #E0E0E0;
    }

    TextField {
        font-size: 16;
        color: black;
        placeholder-color: #C1C1C1;
        padding-left: 15;
    }

    .circle {
        width: 30;
        height: 30;
        color: #42B883;
        font-size: 25;
        border-color: #42B883;
        border-width: 2;
        border-radius: 50;
    }

    Button {
        margin: 15 10 15 15;
        padding-bottom: 3;
    }

    .list-entry {
        padding: 15;
        color: #42B883;
    }

    .list-entry .circle {
        margin-right: 10;
    }

    .list-entry Label {
        font-weight: bold;
        font-size: 17;
        vertical-align: middle;
    }

    .list-entry-completed .circle {
        color: white;
        background-color: #42B883;
        text-align: center;
    }
</style>